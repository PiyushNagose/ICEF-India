Government Recruitment Portal - Handover Bundle

Generated At: 13 Aug 2026, 12:07 am
Scope: Test Job 1 (TJ-01)
Project: Bihar Police Recruitment 2026
Department: Department of Testing
Total Applications: 1
Submitted Applications: 1
Paid Applications: 1
Document Records: 3

Files:
- application-register.csv: Candidate/application master register.
- payment-register.csv: Payment and transaction register.
- correction-register.csv: Admin clarification and correction register.
- document-manifest.csv: Document storage locations and statuses.
- printable-application-register.html: A4-friendly hard-copy register for printing.

Use the document manifest URLs/Public IDs to fetch source documents from the configured storage provider.